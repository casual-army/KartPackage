//lactozilla
freeslot("MT_TAILFLAME", "S_TAILFLAME", "SPR_TF00")
freeslot("SPR_TF00", "SPR_TF01", "SPR_TF02")

mobjinfo[MT_TAILFLAME] = {
	doomednum = -1,
	spawnstate = S_TAILFLAME,
	flags = MF_NOTHINK|MF_NOBLOCKMAP|MF_NOGRAVITY,
}
states[S_TAILFLAME] = {
	sprite = SPR_NULL,
	tics = -1,
}

addHook("ThinkFrame", do
	for charizard in players.iterate do
		if (charizard.mo and charizard.mo.valid) then
			local ov = charizard.flameoverlay
			if (charizard.mo.skin ~= "charizard") then
				if (ov and ov.valid) then
					P_RemoveMobj(ov)
				end
			else
				if (not charizard.mo.valid) then continue end
				local an = charizard.frameangle
				if (ov == nil) or (not ov.valid) then
					charizard.flameoverlay = P_SpawnMobj(0,0,0,MT_TAILFLAME)
					continue
				end
				ov.target = charizard.mo
				if (charizard.mo.state == S_INVISIBLE)
				or (charizard.mo.flags2 & MF2_DONTDRAW)
				or (charizard.mo.eflags & MFE_UNDERWATER)
				or (charizard.mo.frame == R)
				or (gametype == GT_BATTLE and (charizard.kartstuff[k_comebacktimer] != 0) and (charizard.kartstuff[k_bumper] < 1)) then
					ov.sprite = SPR_NULL
				elseif ((charizard.mo.frame == O) or (charizard.mo.frame == P)) then
					ov.sprite = SPR_TF02
					an = $ - ANGLE_45
				elseif ((charizard.mo.frame == M) or (charizard.mo.frame == N)) then
					ov.sprite = SPR_TF01
					an = $ + ANGLE_45
				else
					ov.sprite = SPR_TF00
				end
				ov.scale = charizard.mo.scale
				ov.angle = charizard.frameangle
				ov.flags = MF_NOTHINK|MF_NOBLOCKMAP|MF_NOGRAVITY
				ov.flags2 = charizard.mo.flags2
				ov.eflags = charizard.mo.eflags
				ov.tics = -1
				ov.frame = (leveltime/4 % F)|FF_TRANS30
				local z = charizard.mo.z
				if (ov.flags2 & MF2_OBJECTFLIP)
				or (ov.eflags & MFE_VERTICALFLIP) then
					z = $ + charizard.mo.height
				end
				P_TeleportMove(ov,charizard.mo.x - FixedMul(ov.scale, FixedMul(FRACUNIT*2, cos(an))),charizard.mo.y - FixedMul(ov.scale, FixedMul(FRACUNIT*2, sin(an))),z)
			end
		end
	end
end)