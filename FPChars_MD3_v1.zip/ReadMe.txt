Credit to Prufio for the MD3 models for the Freedom Planet Character Pack.

How to Install MD3s:
1. Merge the "mdls" folder with the same folder in the directory for SRB2Kart
2. Open the "mdls.dat" file with NotePad and add the following...

LILAC KDLC/FP_LILAC.md3 2.9 0.0
CAROL KDLC/FP_CAROL.md3 3.0 0.0
MILLA KDLC/FP_MILLA.md3 2.8 0.0
NEERA KDLC/FP_NEERA.md3 2.9 0.0

3. Save the modified "mdls.dat" file and you should be set!